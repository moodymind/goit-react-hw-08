/* eslint-disable react/prop-types */

export default function Header({ children }) {
  return (
    <h1>
      <title>{children}</title>
    </h1>
  );
}
