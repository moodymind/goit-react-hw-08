export const selectContacts = (state) => state.contacts.contacts.items;
