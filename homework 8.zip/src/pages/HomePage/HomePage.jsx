import Header from "../../components/Header";

export default function HomePage() {
  return (
    <>
      <Header>Home</Header>
      <div>
        <h1>Welcome to the home page</h1>
      </div>
    </>
  );
}
